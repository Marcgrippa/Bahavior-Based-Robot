# Behaviour-Based-Robot
A behaviour based robot created for the subject PLAB-2 (TDT-4113) at NTNU.

This robot uses three of its sensors to do something cool.
